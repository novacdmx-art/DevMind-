# DEVMIND — PROMPT MAESTRO PARA CURSOR / ANTIGRAVITY
# Versión 1.0 — Usa este prompt al abrir el proyecto por primera vez

---

## ¿QUÉ ES DEVMIND?

DevMind es la primera plataforma que fusiona red social técnica + editor de código colaborativo + copiloto de IA contextual + marketplace de conocimiento + sistema de reputación verificable. Está diseñada exclusivamente para desarrolladores e investigadores de IA.

**NO es**: otro foro de programación, un clon de Stack Overflow, ni una red social genérica.
**SÍ es**: la plataforma donde el conocimiento técnico se convierte en capital verificable y el trabajo en equipo sucede dentro de la red.

---

## CONTEXTO DEL PROYECTO (LEE ESTO PRIMERO)

Este repositorio contiene el esqueleto base de DevMind construido con:
- **Frontend**: Next.js 14 (App Router) + TypeScript + Tailwind CSS
- **Backend**: Node.js + Fastify + TypeScript
- **Base de datos**: PostgreSQL con Prisma ORM
- **Tiempo real**: Socket.io
- **IA**: OpenAI API (GPT-4o)
- **Estructura**: Monorepo con Turborepo

El código base ya está escrito. Tu trabajo es **completar, extender y mejorar** lo que existe — nunca reescribir desde cero ni cambiar el stack.

---

## DESIGN SYSTEM — REGLAS ABSOLUTAS DE UI/UX

### Paleta de colores (NUNCA usar otros colores hardcoded)
```
--bg:           #0D0B14   → fondo principal
--surface:      #1A1625   → tarjetas, sidebars
--surface-2:    #231D35   → inputs, hover states
--surface-3:    #2D2548   → elementos elevados
--purple:       #7C3AED   → color de marca, botones primarios
--purple-light: #9F67FF   → texto destacado, iconos activos
--purple-dark:  #4C1D95   → hover de botones
--cyan:         #06B6D4   → tags de tecnología, links
--green:        #10B981   → éxito, online
--yellow:       #F59E0B   → warnings
--red:          #EF4444   → errores
--text:         #F1F5F9   → texto principal
--text-muted:   #94A3B8   → texto secundario
--border:       #3B2F6E   → bordes
```

### Principios de diseño (OBLIGATORIOS)
1. **Dark mode siempre** — el fondo es siempre #0D0B14, jamás blanco
2. **Glassmorphism en navbar y modales**: backdrop-blur + fondo semi-transparente
3. **Glow en hover**: box-shadow purple sutil en tarjetas y botones
4. **Gradient text** en títulos principales: purple-light → cyan
5. **Framer Motion** para TODAS las animaciones (fade-in, hover, loading)
6. **Mobile-first**: diseña primero para 375px, luego escala a desktop
7. **Skeleton loading**: siempre mostrar placeholders mientras carga
8. **Fuente sans**: Inter | Fuente mono: JetBrains Mono

### Componentes ya construidos (NO recrear, usar estos)
- `components/ui/Button.tsx` — variantes: primary, secondary, ghost, danger, outline
- `components/ui/Card.tsx` — con prop hover y glow
- `components/ui/Badge.tsx` + `TechBadge` — para tags de tecnología
- `components/ui/Avatar.tsx` — con ring de color según DevScore
- `components/feed/PostCard.tsx` — tarjeta de post completa con upvote
- `components/layout/Navbar.tsx` — navbar glassmorphism sticky
- `components/layout/Sidebar.tsx` — navegación lateral

---

## ARQUITECTURA DEL CÓDIGO (NO CAMBIAR)

### Estructura de carpetas sagrada
```
devmind/
├── apps/
│   ├── web/          → Next.js frontend
│   └── api/          → Fastify backend
├── packages/
│   ├── db/           → Prisma schema + cliente
│   └── types/        → Tipos TypeScript compartidos
```

### Convenciones de código
- **TypeScript estricto**: sin `any` explícito, sin `@ts-ignore`
- **Imports**: usar `@devmind/types` para tipos, `@devmind/db` para Prisma
- **API client**: SIEMPRE usar `lib/api.ts`, nunca fetch directo
- **Estado**: Zustand para estado global, React Query para datos del servidor
- **Rutas API**: prefijo siempre `/api/`, con `preHandler: authenticate` si requiere auth
- **Errores**: reply.status(código).send({ statusCode, message }) — siempre este formato

### Modelos de base de datos (YA DEFINIDOS en packages/db/prisma/schema.prisma)
Los modelos principales son:
- `User` — con devScore, plan (FREE/PRO/TEAM/ENTERPRISE), stackTags
- `Post` — con type (CODE/ARTICLE/QUESTION/DEBATE), codeContent, language
- `Node` — comunidades técnicas con slug único
- `NodeMember` — membresías con roles (MEMBER/CONTRIBUTOR/MAINTAINER/FOUNDER)
- `Follow` — relaciones follower/following
- `Tag` — tecnologías con color
- `Upvote`, `Comment`, `Notification`, `RefreshToken`

**NUNCA modificar el schema sin entender las relaciones existentes.**

---

## ENDPOINTS YA IMPLEMENTADOS (NO REESCRIBIR)

### Auth — `/api/auth`
- POST `/register` — registro con username, email, password, displayName
- POST `/login` — login con email, password → devuelve accessToken + refreshToken
- POST `/refresh` — renovar accessToken con refreshToken
- POST `/logout` — invalidar refreshToken
- GET `/me` — usuario autenticado actual

### Posts — `/api/posts`
- GET `/` — listar posts (filtros: type, nodeId, tagName, page, limit)
- GET `/:id` — post individual
- POST `/` — crear post [AUTH]
- POST `/:id/upvote` — toggle upvote [AUTH]
- GET `/:id/comments` — comentarios
- POST `/:id/comments` — comentar [AUTH]
- DELETE `/:id` — eliminar [AUTH + autor]

### Feed — `/api/feed`
- GET `/` — feed personalizado [AUTH]
- GET `/trending` — trending global (público)

### Nodes — `/api/nodes`
- GET `/` — listar nodos
- GET `/:slug` — detalle
- POST `/` — crear [AUTH]
- POST `/:slug/join` — unirse [AUTH]
- DELETE `/:slug/leave` — salir [AUTH]
- GET `/:slug/posts` — posts del nodo

### Users — `/api/users`
- GET `/:username` — perfil público
- PATCH `/me` — actualizar perfil [AUTH]
- POST `/:username/follow` — seguir [AUTH]
- DELETE `/:username/follow` — dejar de seguir [AUTH]
- GET `/:username/posts` — posts del usuario
- PATCH `/me/stack` — actualizar stack tecnológico [AUTH]
- GET `/me/notifications` — notificaciones [AUTH]

### AI — `/api/ai`
- POST `/review-code` — revisión de código con GPT-4o [AUTH]
- POST `/generate-tags` — sugerir tags automáticos [AUTH]
- POST `/summarize-thread` — resumir hilo de comentarios [AUTH]

---

## WEBSOCKET EVENTS (Socket.io)

### Servidor → Cliente
- `notification:new` — nueva notificación
- `feed:new-post` — nuevo post de alguien que sigues
- `post:upvote-updated` — counter de upvotes cambió
- `post:comment-added` — nuevo comentario en post abierto

### Cliente → Servidor
- `room:join-post` — suscribirse a updates de un post
- `room:leave-post` — desuscribirse
- `room:join-node` — suscribirse a updates de un nodo
- `typing:start` / `typing:stop` — indicador de escritura

---

## FASES DE CONSTRUCCIÓN

### FASE 1 — MVP (YA INICIADA, completar esto):

**Backend — completar:**
- [ ] Endpoints de AI funcionando con clave real de OpenAI
- [ ] Sistema de notificaciones: emitir via Socket.io cuando ocurren eventos
- [ ] Rate limiting específico por endpoint
- [ ] Validación con Zod en todos los endpoints

**Frontend — completar:**
- [ ] Página de perfil `/main/profile/[username]` con stats, stack y posts
- [ ] Página de nodo `/main/nodes/[slug]` con posts y miembros
- [ ] Página de post individual `/main/posts/[id]` con comentarios
- [ ] Formulario de crear post con editor Monaco para código
- [ ] Conexión Socket.io para notificaciones en tiempo real
- [ ] Componente de búsqueda en Navbar funcional
- [ ] Página de explorar nodos `/main/nodes`

### FASE 2 — (pendiente, construir después de Fase 1):
- DevJobs: modelo Job ya en schema, construir UI y endpoints
- DevMarket: cursos, templates, integración Stripe
- Monaco Editor completo en el creador de posts
- Code review con IA visible en el PostCard

### FASE 3 — (pendiente, largo plazo):
- Sandbox de ejecución de código (microservicio separado en Docker)
- DevPulse analytics con ClickHouse
- DevLabs (incubadora) con cohorts
- Pair programming con Yjs + WebRTC

---

## CÓMO INICIAR EL PROYECTO

```bash
# 1. Instalar dependencias
npm install

# 2. Copiar variables de entorno
cp .env.example .env
# Editar .env con tus claves reales

# 3. Generar cliente Prisma
npm run db:generate

# 4. Ejecutar migraciones
npm run db:migrate

# 5. Sembrar datos de prueba
npm run db:seed

# 6. Iniciar en desarrollo
npm run dev
# Frontend: http://localhost:3000
# Backend:  http://localhost:4000
```

---

## REGLAS PARA LA IA QUE CONSTRUYE ESTE PROYECTO

1. **Respetar el design system dark purple** — cada componente nuevo debe usar las variables CSS definidas, nunca colores hardcoded.

2. **Mobile-first siempre** — todo componente debe ser responsive. Usar clases `sm:`, `md:`, `lg:` de Tailwind.

3. **No reinventar la rueda** — antes de crear algo nuevo, verificar si ya existe en `components/ui/` o en los routes del backend.

4. **Consistencia de errores** — todos los errores del API siguen el formato `{ statusCode, message }`.

5. **Animaciones con Framer Motion** — usar `motion.div`, `AnimatePresence`, variantes de animación. No usar CSS animations para interacciones.

6. **Tipos compartidos** — usar `@devmind/types` para tipos comunes entre frontend y backend.

7. **Comentarios en código** — cada archivo debe tener un comentario en la primera línea indicando su ruta y propósito.

8. **DevScore** — el sistema de reputación es importante. Cada acción relevante (post publicado, upvote recibido, comentario útil) debe potencialmente afectar el devScore del usuario.

9. **La IA de DevMind es contextual** — no es un chatbot genérico. Siempre que integres IA, debe conocer el contexto: el stack del usuario, sus posts anteriores, el nodo en el que está.

10. **Privacidad** — datos de usuario nunca en logs. Contraseñas siempre hasheadas con bcrypt. Tokens en localStorage con expiración.

---

## RECURSOS DE REFERENCIA

- Documento Maestro de Producto: `DevMind_Documento_Maestro.docx`
- Documento de Arquitectura Técnica: `DevMind_Arquitectura_Tecnica.docx`
- Schema de BD: `packages/db/prisma/schema.prisma`
- Tipos compartidos: `packages/types/index.ts`
- Variables de entorno: `.env.example`

---

## PREGUNTA DE VERIFICACIÓN

Antes de empezar a construir cualquier feature, hazte estas preguntas:

1. ¿Ya existe algo parecido en el código base?
2. ¿Estoy respetando el design system dark purple?
3. ¿El componente es responsive en mobile?
4. ¿Los errores siguen el formato estándar?
5. ¿El endpoint requiere autenticación y lo tiene?
6. ¿Usé framer-motion para las animaciones?

Si la respuesta es NO a cualquiera, corrígelo antes de continuar.

---

*DevMind — Build. Learn. Earn. Together.*
*Prompt Maestro v1.0 — Confidencial*
