// packages/types/index.ts
// Tipos compartidos entre frontend y backend

export interface UserPublic {
  id: string
  username: string
  displayName: string
  avatarUrl: string | null
  bio: string | null
  devScore: number
  plan: 'FREE' | 'PRO' | 'TEAM' | 'ENTERPRISE'
  createdAt: string
  _count?: {
    followers: number
    following: number
    posts: number
  }
}

export interface PostWithAuthor {
  id: string
  type: 'CODE' | 'ARTICLE' | 'QUESTION' | 'DEBATE'
  title: string | null
  content: string
  codeContent: string | null
  language: string | null
  upvotesCount: number
  commentsCount: number
  viewsCount: number
  createdAt: string
  author: UserPublic
  node?: NodePublic | null
  tags: TagPublic[]
  hasUpvoted?: boolean
}

export interface NodePublic {
  id: string
  name: string
  slug: string
  description: string
  iconUrl: string | null
  membersCount: number
  postsCount: number
  tags: TagPublic[]
}

export interface TagPublic {
  id: string
  name: string
  color: string
}

export interface CommentWithAuthor {
  id: string
  content: string
  createdAt: string
  author: UserPublic
  replies?: CommentWithAuthor[]
}

export interface NotificationPayload {
  id: string
  type: string
  message: string
  isRead: boolean
  createdAt: string
  actor?: UserPublic
  postId?: string
}

export interface PaginatedResponse<T> {
  data: T[]
  total: number
  page: number
  pageSize: number
  hasMore: boolean
}

export interface ApiError {
  statusCode: number
  message: string
  error?: string
}

// WebSocket events
export interface WsNotificationNew {
  notification: NotificationPayload
}

export interface WsFeedNewPost {
  post: PostWithAuthor
}

export interface WsPostUpvateUpdated {
  postId: string
  count: number
}

export interface WsPostCommentAdded {
  postId: string
  comment: CommentWithAuthor
}
