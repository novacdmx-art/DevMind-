// packages/db/seed.ts
// Ejecutar: npx prisma db seed

import { PrismaClient } from '@prisma/client'
import bcrypt from 'bcryptjs'

const prisma = new PrismaClient()

async function main() {
  console.log('🌱 Seeding DevMind database...')

  // Tags / Tecnologías
  const tags = await Promise.all([
    prisma.tag.upsert({ where: { name: 'typescript' }, update: {}, create: { name: 'typescript', color: '#3178C6' } }),
    prisma.tag.upsert({ where: { name: 'react' }, update: {}, create: { name: 'react', color: '#61DAFB' } }),
    prisma.tag.upsert({ where: { name: 'nodejs' }, update: {}, create: { name: 'nodejs', color: '#339933' } }),
    prisma.tag.upsert({ where: { name: 'python' }, update: {}, create: { name: 'python', color: '#3776AB' } }),
    prisma.tag.upsert({ where: { name: 'llm' }, update: {}, create: { name: 'llm', color: '#9F67FF' } }),
    prisma.tag.upsert({ where: { name: 'rust' }, update: {}, create: { name: 'rust', color: '#CE412B' } }),
    prisma.tag.upsert({ where: { name: 'nextjs' }, update: {}, create: { name: 'nextjs', color: '#FFFFFF' } }),
    prisma.tag.upsert({ where: { name: 'postgresql' }, update: {}, create: { name: 'postgresql', color: '#336791' } }),
  ])

  // Usuarios de prueba
  const passwordHash = await bcrypt.hash('DevMind2024!', 12)

  const users = await Promise.all([
    prisma.user.upsert({
      where: { username: 'alexdev' },
      update: {},
      create: {
        username: 'alexdev', email: 'alex@devmind.io',
        displayName: 'Alex Rivera', passwordHash,
        bio: 'Full-stack dev | TypeScript enthusiast | Open source contributor',
        devScore: 1250, emailVerified: true,
      }
    }),
    prisma.user.upsert({
      where: { username: 'sara_ml' },
      update: {},
      create: {
        username: 'sara_ml', email: 'sara@devmind.io',
        displayName: 'Sara Chen', passwordHash,
        bio: 'ML Engineer | LLMs & RAG systems | Python lover',
        devScore: 980, emailVerified: true,
      }
    }),
    prisma.user.upsert({
      where: { username: 'rustacean' },
      update: {},
      create: {
        username: 'rustacean', email: 'rust@devmind.io',
        displayName: 'Marco Díaz', passwordHash,
        bio: 'Systems programmer | Rust & Go | Performance obsessed',
        devScore: 2100, emailVerified: true,
      }
    }),
  ])

  // Nodos
  const nodes = await Promise.all([
    prisma.node.upsert({
      where: { slug: 'typescript' },
      update: {},
      create: {
        name: 'TypeScript Hub', slug: 'typescript',
        description: 'Todo sobre TypeScript: tipos avanzados, patrones, decorators y más.',
        membersCount: 1,
      }
    }),
    prisma.node.upsert({
      where: { slug: 'llm-ai' },
      update: {},
      create: {
        name: 'LLM & AI Engineering', slug: 'llm-ai',
        description: 'Construye con LLMs: RAG, fine-tuning, agentes, prompting avanzado.',
        membersCount: 1,
      }
    }),
    prisma.node.upsert({
      where: { slug: 'rust-systems' },
      update: {},
      create: {
        name: 'Rust & Systems', slug: 'rust-systems',
        description: 'Programación de sistemas con Rust: ownership, lifetimes, async.',
        membersCount: 1,
      }
    }),
  ])

  // Posts de prueba
  await prisma.post.createMany({
    skipDuplicates: true,
    data: [
      {
        id: 'post_seed_1',
        type: 'CODE',
        title: 'Type-safe API client con TypeScript generics',
        content: 'Aquí un patrón que uso para crear clientes HTTP completamente type-safe sin código repetido.',
        codeContent: `type ApiResponse<T> = { data: T; error: null } | { data: null; error: string }

async function fetchApi<T>(url: string): Promise<ApiResponse<T>> {
  try {
    const res = await fetch(url)
    if (!res.ok) return { data: null, error: res.statusText }
    const data: T = await res.json()
    return { data, error: null }
  } catch (err) {
    return { data: null, error: String(err) }
  }
}

// Uso: completamente tipado
const { data, error } = await fetchApi<User[]>('/api/users')`,
        language: 'typescript',
        authorId: users[0].id,
        nodeId: nodes[0].id,
        upvotesCount: 47,
        commentsCount: 8,
      },
      {
        id: 'post_seed_2',
        type: 'ARTICLE',
        title: 'RAG con pgvector: embeddings en tu PostgreSQL',
        content: 'No necesitas una base de datos vectorial separada para empezar con RAG. pgvector te permite guardar embeddings directamente en PostgreSQL. En este post explico cómo configurarlo y hacer búsquedas semánticas reales.',
        authorId: users[1].id,
        nodeId: nodes[1].id,
        upvotesCount: 92,
        commentsCount: 15,
      },
      {
        id: 'post_seed_3',
        type: 'CODE',
        title: 'Zero-cost abstractions en Rust: un ejemplo real',
        content: 'Este snippet demuestra cómo Rust compila iteradores encadenados al mismo código que un loop manual. Cero overhead en runtime.',
        codeContent: `// Esto en Rust compila exactamente igual que el loop manual
fn sum_even_squares(numbers: &[i32]) -> i32 {
    numbers
        .iter()
        .filter(|&&x| x % 2 == 0)
        .map(|&x| x * x)
        .sum()
}

// El compilador genera el mismo assembly que:
fn sum_even_squares_manual(numbers: &[i32]) -> i32 {
    let mut total = 0;
    for &x in numbers {
        if x % 2 == 0 { total += x * x; }
    }
    total
}`,
        language: 'rust',
        authorId: users[2].id,
        nodeId: nodes[2].id,
        upvotesCount: 134,
        commentsCount: 22,
      },
    ]
  })

  console.log('✅ Seed completado:')
  console.log(`   ${tags.length} tags | ${users.length} usuarios | ${nodes.length} nodos | 3 posts`)
  console.log('\nCredenciales de prueba:')
  console.log('   Email: alex@devmind.io | Password: DevMind2024!')
}

main()
  .catch((e) => { console.error(e); process.exit(1) })
  .finally(async () => { await prisma.$disconnect() })
