# DevMind 🚀

**La red social-productiva para desarrolladores e investigadores de IA.**

> DevMind no es otro foro. Es la primera plataforma que fusiona comunidad técnica, productividad real, inteligencia artificial contextual y monetización justa — para devs que construyen en serio.

---

## Stack

| Capa | Tecnología |
|------|-----------|
| Frontend | Next.js 14, TypeScript, Tailwind CSS, Framer Motion |
| Backend | Node.js, Fastify, TypeScript |
| Base de datos | PostgreSQL (Prisma ORM) + Redis |
| Tiempo real | Socket.io |
| IA | OpenAI GPT-4o |
| Deploy | Vercel (web) + Railway (api) |

## Inicio rápido

```bash
npm install
cp .env.example .env   # Agregar tus claves
npm run db:migrate
npm run db:seed
npm run dev
```

Frontend: `http://localhost:3000`  
Backend: `http://localhost:4000`

## Para construir con IA (Cursor / Antigravity)

**Lee primero**: `CURSOR_PROMPT.md` — contiene todo el contexto del proyecto, las reglas de diseño, los endpoints existentes y las fases de construcción.

## Documentación

- `DevMind_Documento_Maestro.docx` — Visión, producto y modelo de negocio
- `DevMind_Arquitectura_Tecnica.docx` — Blueprint técnico completo

---

*DevMind — Build. Learn. Earn. Together.*
