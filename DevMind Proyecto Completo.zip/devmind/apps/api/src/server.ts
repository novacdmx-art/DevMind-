// apps/api/src/server.ts
import 'dotenv/config'
import Fastify from 'fastify'
import cors from '@fastify/cors'
import jwt from '@fastify/jwt'
import helmet from '@fastify/helmet'
import rateLimit from '@fastify/rate-limit'
import { createServer } from 'http'
import { Server as SocketServer } from 'socket.io'

import { authRoutes } from './routes/auth.routes'
import { usersRoutes } from './routes/users.routes'
import { postsRoutes } from './routes/posts.routes'
import { nodesRoutes } from './routes/nodes.routes'
import { feedRoutes } from './routes/feed.routes'
import { aiRoutes } from './routes/ai.routes'
import { setupWebSocket } from './websocket/socket.handler'

const app = Fastify({
  logger: {
    level: process.env.NODE_ENV === 'development' ? 'info' : 'warn',
  },
})

const httpServer = createServer(app.server)

// ── Socket.io ─────────────────────────────────────────────────────────────────
export const io = new SocketServer(httpServer, {
  cors: {
    origin: process.env.FRONTEND_URL || 'http://localhost:3000',
    credentials: true,
  },
})
setupWebSocket(io)

// ── Plugins ───────────────────────────────────────────────────────────────────
async function registerPlugins() {
  await app.register(helmet, { contentSecurityPolicy: false })

  await app.register(cors, {
    origin: process.env.FRONTEND_URL || 'http://localhost:3000',
    credentials: true,
    methods: ['GET', 'POST', 'PUT', 'PATCH', 'DELETE', 'OPTIONS'],
  })

  await app.register(jwt, {
    secret: process.env.JWT_SECRET || 'devmind-dev-secret-change-in-production',
    sign: { expiresIn: process.env.JWT_EXPIRES_IN || '15m' },
  })

  await app.register(rateLimit, {
    max: 100,
    timeWindow: '1 minute',
    errorResponseBuilder: () => ({
      statusCode: 429,
      error: 'Too Many Requests',
      message: 'Demasiadas peticiones. Intenta en un momento.',
    }),
  })
}

// ── Rutas ─────────────────────────────────────────────────────────────────────
async function registerRoutes() {
  await app.register(authRoutes, { prefix: '/api/auth' })
  await app.register(usersRoutes, { prefix: '/api/users' })
  await app.register(postsRoutes, { prefix: '/api/posts' })
  await app.register(nodesRoutes, { prefix: '/api/nodes' })
  await app.register(feedRoutes, { prefix: '/api/feed' })
  await app.register(aiRoutes, { prefix: '/api/ai' })
}

// ── Health check ──────────────────────────────────────────────────────────────
app.get('/health', async () => ({
  status: 'ok',
  timestamp: new Date().toISOString(),
  env: process.env.NODE_ENV,
}))

// ── Error handler ─────────────────────────────────────────────────────────────
app.setErrorHandler((error, _request, reply) => {
  app.log.error(error)
  const statusCode = error.statusCode || 500
  reply.status(statusCode).send({
    statusCode,
    error: error.name,
    message: error.message || 'Error interno del servidor',
  })
})

// ── Boot ──────────────────────────────────────────────────────────────────────
async function start() {
  try {
    await registerPlugins()
    await registerRoutes()

    const PORT = Number(process.env.PORT) || 4000
    await app.listen({ port: PORT, host: '0.0.0.0' })
    console.log(`\n🚀 DevMind API corriendo en http://localhost:${PORT}`)
    console.log(`⚡ WebSocket escuchando en puerto ${PORT}`)
    console.log(`🌍 Entorno: ${process.env.NODE_ENV || 'development'}\n`)
  } catch (err) {
    app.log.error(err)
    process.exit(1)
  }
}

start()
