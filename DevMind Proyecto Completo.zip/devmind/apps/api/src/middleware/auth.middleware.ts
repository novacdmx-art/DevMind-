// apps/api/src/middleware/auth.middleware.ts
import { FastifyRequest, FastifyReply } from 'fastify'

export async function authenticate(request: FastifyRequest, reply: FastifyReply) {
  try {
    await request.jwtVerify()
  } catch {
    reply.status(401).send({ statusCode: 401, error: 'Unauthorized', message: 'Token inválido o expirado.' })
  }
}

export async function optionalAuthenticate(request: FastifyRequest) {
  try {
    await request.jwtVerify()
  } catch {
    // No forzamos auth — el handler revisará si request.user existe
  }
}
