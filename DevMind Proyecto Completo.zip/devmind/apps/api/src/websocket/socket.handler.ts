// apps/api/src/websocket/socket.handler.ts
import { Server, Socket } from 'socket.io'
import jwt from 'jsonwebtoken'

interface AuthenticatedSocket extends Socket {
  userId?: string
  username?: string
}

export function setupWebSocket(io: Server) {
  // Middleware de autenticación para WebSocket
  io.use((socket: AuthenticatedSocket, next) => {
    const token = socket.handshake.auth.token || socket.handshake.headers.authorization?.split(' ')[1]
    if (!token) return next() // Permitir conexiones anónimas (solo reciben trending)

    try {
      const decoded = jwt.verify(token, process.env.JWT_SECRET || 'devmind-dev-secret-change-in-production') as any
      socket.userId = decoded.userId
      socket.username = decoded.username
      next()
    } catch {
      next() // Token inválido = conexión anónima
    }
  })

  io.on('connection', (socket: AuthenticatedSocket) => {
    // Unirse a sala personal si está autenticado
    if (socket.userId) {
      socket.join(`user:${socket.userId}`)
    }

    // Unirse a sala de un post específico (para updates en tiempo real)
    socket.on('room:join-post', ({ postId }: { postId: string }) => {
      socket.join(`post:${postId}`)
    })

    socket.on('room:leave-post', ({ postId }: { postId: string }) => {
      socket.leave(`post:${postId}`)
    })

    // Suscribirse a un nodo
    socket.on('room:join-node', ({ nodeSlug }: { nodeSlug: string }) => {
      socket.join(`node:${nodeSlug}`)
    })

    // Indicador "está escribiendo"
    socket.on('typing:start', ({ postId }: { postId: string }) => {
      socket.to(`post:${postId}`).emit('typing:start', { username: socket.username })
    })

    socket.on('typing:stop', ({ postId }: { postId: string }) => {
      socket.to(`post:${postId}`).emit('typing:stop', { username: socket.username })
    })

    socket.on('disconnect', () => {
      // Cleanup automático de rooms al desconectar
    })
  })
}

// Helpers para emitir eventos desde los routes/services
export function emitToUser(io: Server, userId: string, event: string, data: any) {
  io.to(`user:${userId}`).emit(event, data)
}

export function emitToPost(io: Server, postId: string, event: string, data: any) {
  io.to(`post:${postId}`).emit(event, data)
}

export function emitToNode(io: Server, nodeSlug: string, event: string, data: any) {
  io.to(`node:${nodeSlug}`).emit(event, data)
}
