// apps/api/src/routes/users.routes.ts
import { FastifyInstance } from 'fastify'
import { prisma } from '@devmind/db'
import { authenticate, optionalAuthenticate } from '../middleware/auth.middleware'

export async function usersRoutes(app: FastifyInstance) {
  // GET /api/users/:username — perfil público
  app.get('/:username', { preHandler: optionalAuthenticate }, async (request, reply) => {
    const { username } = request.params as { username: string }
    const currentUserId = (request.user as any)?.userId

    const user = await prisma.user.findUnique({
      where: { username },
      select: {
        id: true, username: true, displayName: true, bio: true,
        avatarUrl: true, websiteUrl: true, githubUrl: true, devScore: true,
        plan: true, createdAt: true,
        _count: { select: { followers: true, following: true, posts: true } },
        stackTags: { select: { level: true, tag: { select: { id: true, name: true, color: true } } } },
      },
    })
    if (!user) return reply.status(404).send({ message: 'Usuario no encontrado.' })

    let isFollowing = false
    if (currentUserId && currentUserId !== user.id) {
      const follow = await prisma.follow.findUnique({
        where: { followerId_followingId: { followerId: currentUserId, followingId: user.id } },
      })
      isFollowing = !!follow
    }

    return reply.send({ ...user, isFollowing })
  })

  // PATCH /api/users/me — actualizar mi perfil
  app.patch('/me', { preHandler: authenticate }, async (request, reply) => {
    const { userId } = request.user as { userId: string }
    const { displayName, bio, avatarUrl, websiteUrl, githubUrl } = request.body as any

    const user = await prisma.user.update({
      where: { id: userId },
      data: { displayName, bio, avatarUrl, websiteUrl, githubUrl },
      select: { id: true, username: true, displayName: true, bio: true, avatarUrl: true, websiteUrl: true, devScore: true },
    })
    return reply.send(user)
  })

  // POST /api/users/:username/follow
  app.post('/:username/follow', { preHandler: authenticate }, async (request, reply) => {
    const { userId: followerId } = request.user as { userId: string }
    const { username } = request.params as { username: string }

    const target = await prisma.user.findUnique({ where: { username }, select: { id: true } })
    if (!target) return reply.status(404).send({ message: 'Usuario no encontrado.' })
    if (target.id === followerId) return reply.status(400).send({ message: 'No puedes seguirte a ti mismo.' })

    const existing = await prisma.follow.findUnique({
      where: { followerId_followingId: { followerId, followingId: target.id } },
    })
    if (existing) return reply.status(409).send({ message: 'Ya sigues a este usuario.' })

    await prisma.follow.create({ data: { followerId, followingId: target.id } })
    await prisma.notification.create({
      data: { type: 'NEW_FOLLOWER', recipientId: target.id, actorId: followerId, message: 'comenzó a seguirte.' },
    })
    return reply.send({ success: true })
  })

  // DELETE /api/users/:username/follow
  app.delete('/:username/follow', { preHandler: authenticate }, async (request, reply) => {
    const { userId: followerId } = request.user as { userId: string }
    const { username } = request.params as { username: string }

    const target = await prisma.user.findUnique({ where: { username }, select: { id: true } })
    if (!target) return reply.status(404).send({ message: 'Usuario no encontrado.' })

    await prisma.follow.deleteMany({ where: { followerId, followingId: target.id } })
    return reply.send({ success: true })
  })

  // GET /api/users/:username/posts
  app.get('/:username/posts', async (request, reply) => {
    const { username } = request.params as { username: string }
    const { page = 1, limit = 20 } = request.query as any
    const skip = (Number(page) - 1) * Number(limit)

    const user = await prisma.user.findUnique({ where: { username }, select: { id: true } })
    if (!user) return reply.status(404).send({ message: 'Usuario no encontrado.' })

    const posts = await prisma.post.findMany({
      where: { authorId: user.id, isPublished: true },
      skip, take: Number(limit),
      orderBy: { createdAt: 'desc' },
      select: {
        id: true, type: true, title: true, content: true, language: true,
        upvotesCount: true, commentsCount: true, createdAt: true,
        tags: { select: { tag: { select: { id: true, name: true, color: true } } } },
        node: { select: { id: true, name: true, slug: true } },
      },
    })
    return reply.send({ data: posts, page: Number(page), hasMore: posts.length === Number(limit) })
  })

  // PATCH /api/users/me/stack
  app.patch('/me/stack', { preHandler: authenticate }, async (request, reply) => {
    const { userId } = request.user as { userId: string }
    const { stack } = request.body as { stack: Array<{ tagId: string; level: number }> }

    await prisma.userStack.deleteMany({ where: { userId } })
    if (stack?.length) {
      await prisma.userStack.createMany({ data: stack.map(s => ({ userId, tagId: s.tagId, level: s.level })) })
    }
    return reply.send({ success: true })
  })

  // GET /api/users/me/notifications
  app.get('/me/notifications', { preHandler: authenticate }, async (request, reply) => {
    const { userId } = request.user as { userId: string }
    const { limit = 20 } = request.query as any

    const notifications = await prisma.notification.findMany({
      where: { recipientId: userId },
      take: Number(limit),
      orderBy: { createdAt: 'desc' },
      select: {
        id: true, type: true, message: true, isRead: true, postId: true, createdAt: true,
        actor: { select: { id: true, username: true, displayName: true, avatarUrl: true } },
      },
    })

    // Marcar como leídas
    await prisma.notification.updateMany({ where: { recipientId: userId, isRead: false }, data: { isRead: true } })

    return reply.send({ data: notifications })
  })
}
