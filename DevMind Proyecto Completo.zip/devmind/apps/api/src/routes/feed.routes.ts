// apps/api/src/routes/feed.routes.ts
import { FastifyInstance } from 'fastify'
import { prisma } from '@devmind/db'
import { authenticate, optionalAuthenticate } from '../middleware/auth.middleware'

const postSelect = {
  id: true, type: true, title: true, content: true, codeContent: true,
  language: true, upvotesCount: true, commentsCount: true, viewsCount: true,
  isPinned: true, createdAt: true,
  author: { select: { id: true, username: true, displayName: true, avatarUrl: true, devScore: true } },
  node: { select: { id: true, name: true, slug: true } },
  tags: { select: { tag: { select: { id: true, name: true, color: true } } } },
}

export async function feedRoutes(app: FastifyInstance) {
  // GET /api/feed — feed personalizado del usuario autenticado
  app.get('/', { preHandler: authenticate }, async (request, reply) => {
    const { userId } = request.user as { userId: string }
    const { page = 1, limit = 20 } = request.query as any
    const skip = (Number(page) - 1) * Number(limit)

    // Obtener IDs de usuarios que sigo
    const following = await prisma.follow.findMany({
      where: { followerId: userId },
      select: { followingId: true },
    })
    const followingIds = following.map(f => f.followingId)

    // Obtener nodos a los que pertenezco
    const myNodes = await prisma.nodeMember.findMany({
      where: { userId },
      select: { nodeId: true },
    })
    const myNodeIds = myNodes.map(n => n.nodeId)

    // Feed: posts de usuarios seguidos + posts de mis nodos (últimas 72h)
    const posts = await prisma.post.findMany({
      where: {
        isPublished: true,
        OR: [
          { authorId: { in: followingIds } },
          { nodeId: { in: myNodeIds } },
        ],
      },
      skip,
      take: Number(limit),
      orderBy: { createdAt: 'desc' },
      select: postSelect,
    })

    return reply.send({ data: posts, page: Number(page), hasMore: posts.length === Number(limit) })
  })

  // GET /api/feed/trending — trending global (sin auth)
  app.get('/trending', { preHandler: optionalAuthenticate }, async (request, reply) => {
    const { limit = 20 } = request.query as any

    // Trending: posts con más upvotes en las últimas 48 horas
    const since = new Date(Date.now() - 48 * 60 * 60 * 1000)

    const posts = await prisma.post.findMany({
      where: { isPublished: true, createdAt: { gte: since } },
      orderBy: [{ upvotesCount: 'desc' }, { commentsCount: 'desc' }],
      take: Number(limit),
      select: postSelect,
    })

    return reply.send({ data: posts })
  })
}
