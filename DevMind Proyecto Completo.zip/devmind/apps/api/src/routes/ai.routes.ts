// apps/api/src/routes/ai.routes.ts
import { FastifyInstance } from 'fastify'
import OpenAI from 'openai'
import { authenticate } from '../middleware/auth.middleware'

const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY })

export async function aiRoutes(app: FastifyInstance) {
  // POST /api/ai/review-code
  app.post('/review-code', {
    preHandler: authenticate,
    config: { rateLimit: { max: 10, timeWindow: '1 hour' } },
  }, async (request, reply) => {
    const { code, language } = request.body as { code: string; language: string }
    if (!code?.trim()) return reply.status(400).send({ message: 'Código requerido.' })

    try {
      const completion = await openai.chat.completions.create({
        model: process.env.OPENAI_MODEL || 'gpt-4o',
        max_tokens: 800,
        messages: [
          {
            role: 'system',
            content: `Eres un senior developer revisando código de la plataforma DevMind. Responde en JSON con este formato exacto:
{"bugs": ["bug1", "bug2"], "suggestions": ["sug1", "sug2"], "quality": 85, "summary": "resumen breve"}
Sé conciso y técnico. quality es un número 0-100.`,
          },
          { role: 'user', content: `Lenguaje: ${language}\n\nCódigo:\n${code.slice(0, 3000)}` },
        ],
      })

      const content = completion.choices[0].message.content || '{}'
      const clean = content.replace(/```json|```/g, '').trim()
      const review = JSON.parse(clean)
      return reply.send(review)
    } catch (error) {
      return reply.status(500).send({ message: 'Error al analizar el código. Intenta de nuevo.' })
    }
  })

  // POST /api/ai/generate-tags
  app.post('/generate-tags', {
    preHandler: authenticate,
    config: { rateLimit: { max: 30, timeWindow: '1 hour' } },
  }, async (request, reply) => {
    const { title, content, code } = request.body as { title?: string; content: string; code?: string }

    try {
      const text = [title, content, code].filter(Boolean).join('\n').slice(0, 2000)
      const completion = await openai.chat.completions.create({
        model: 'gpt-4o-mini',
        max_tokens: 100,
        messages: [
          { role: 'system', content: 'Extrae tecnologías y conceptos de programación del texto. Responde solo con un JSON array de strings en minúsculas, máximo 5 items. Ejemplo: ["typescript","react","hooks"]' },
          { role: 'user', content: text },
        ],
      })
      const raw = completion.choices[0].message.content || '[]'
      const tags = JSON.parse(raw.replace(/```json|```/g, '').trim())
      return reply.send({ tags })
    } catch {
      return reply.send({ tags: [] })
    }
  })

  // POST /api/ai/summarize-thread
  app.post('/summarize-thread', {
    preHandler: authenticate,
    config: { rateLimit: { max: 20, timeWindow: '1 hour' } },
  }, async (request, reply) => {
    const { postContent, comments } = request.body as { postContent: string; comments: Array<{ author: string; content: string }> }

    const commentsText = comments.slice(0, 20).map(c => `${c.author}: ${c.content}`).join('\n')

    try {
      const completion = await openai.chat.completions.create({
        model: 'gpt-4o-mini',
        max_tokens: 300,
        messages: [
          { role: 'system', content: 'Resume este hilo de discusión técnica en 2-3 oraciones claras. Destaca los puntos principales del debate y cualquier conclusión o consenso alcanzado. Responde en español.' },
          { role: 'user', content: `Post:\n${postContent}\n\nComentarios:\n${commentsText}` },
        ],
      })
      return reply.send({ summary: completion.choices[0].message.content })
    } catch {
      return reply.status(500).send({ message: 'Error al generar el resumen.' })
    }
  })
}
