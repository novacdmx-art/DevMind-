// apps/api/src/routes/posts.routes.ts
import { FastifyInstance } from 'fastify'
import { z } from 'zod'
import { prisma } from '@devmind/db'
import { authenticate, optionalAuthenticate } from '../middleware/auth.middleware'

const createPostSchema = z.object({
  type: z.enum(['CODE', 'ARTICLE', 'QUESTION', 'DEBATE']),
  title: z.string().max(200).optional(),
  content: z.string().min(10).max(10000),
  codeContent: z.string().max(50000).optional(),
  language: z.string().max(30).optional(),
  nodeId: z.string().optional(),
  tagIds: z.array(z.string()).max(5).optional(),
})

const postSelect = {
  id: true, type: true, title: true, content: true, codeContent: true,
  language: true, upvotesCount: true, commentsCount: true, viewsCount: true,
  isPinned: true, createdAt: true, updatedAt: true,
  author: { select: { id: true, username: true, displayName: true, avatarUrl: true, devScore: true } },
  node: { select: { id: true, name: true, slug: true } },
  tags: { select: { tag: { select: { id: true, name: true, color: true } } } },
}

export async function postsRoutes(app: FastifyInstance) {
  // GET /api/posts — listar posts con paginación
  app.get('/', { preHandler: optionalAuthenticate }, async (request, reply) => {
    const { page = 1, limit = 20, type, nodeId, tagName } = request.query as any
    const skip = (Number(page) - 1) * Number(limit)

    const where: any = { isPublished: true }
    if (type) where.type = type
    if (nodeId) where.nodeId = nodeId
    if (tagName) where.tags = { some: { tag: { name: tagName } } }

    const [posts, total] = await Promise.all([
      prisma.post.findMany({ where, skip, take: Number(limit), orderBy: { createdAt: 'desc' }, select: postSelect }),
      prisma.post.count({ where }),
    ])

    return reply.send({ data: posts, total, page: Number(page), hasMore: skip + posts.length < total })
  })

  // GET /api/posts/:id — post individual
  app.get('/:id', { preHandler: optionalAuthenticate }, async (request, reply) => {
    const { id } = request.params as { id: string }
    const userId = (request.user as any)?.userId

    const post = await prisma.post.findUnique({ where: { id }, select: postSelect })
    if (!post) return reply.status(404).send({ statusCode: 404, message: 'Post no encontrado.' })

    // Incrementar vistas
    await prisma.post.update({ where: { id }, data: { viewsCount: { increment: 1 } } })

    // Verificar si el usuario ya votó
    let hasUpvoted = false
    if (userId) {
      const upvote = await prisma.upvote.findUnique({ where: { userId_postId: { userId, postId: id } } })
      hasUpvoted = !!upvote
    }

    return reply.send({ ...post, hasUpvoted })
  })

  // POST /api/posts — crear post
  app.post('/', { preHandler: authenticate }, async (request, reply) => {
    const { userId } = request.user as { userId: string }
    const body = createPostSchema.safeParse(request.body)
    if (!body.success) return reply.status(400).send({ statusCode: 400, message: body.error.errors[0].message })

    const { tagIds, ...postData } = body.data
    const post = await prisma.post.create({
      data: {
        ...postData,
        authorId: userId,
        tags: tagIds?.length ? { create: tagIds.map(tagId => ({ tagId })) } : undefined,
      },
      select: postSelect,
    })

    // Actualizar conteo del nodo si aplica
    if (post.node) {
      await prisma.node.update({ where: { id: post.node.id }, data: { postsCount: { increment: 1 } } })
    }

    return reply.status(201).send(post)
  })

  // POST /api/posts/:id/upvote — toggle upvote
  app.post('/:id/upvote', { preHandler: authenticate }, async (request, reply) => {
    const { userId } = request.user as { userId: string }
    const { id: postId } = request.params as { id: string }

    const existing = await prisma.upvote.findUnique({ where: { userId_postId: { userId, postId } } })

    if (existing) {
      await prisma.upvote.delete({ where: { userId_postId: { userId, postId } } })
      await prisma.post.update({ where: { id: postId }, data: { upvotesCount: { decrement: 1 } } })
      return reply.send({ upvoted: false })
    } else {
      await prisma.upvote.create({ data: { userId, postId } })
      const post = await prisma.post.update({
        where: { id: postId },
        data: { upvotesCount: { increment: 1 } },
        select: { authorId: true, upvotesCount: true },
      })

      // Notificar al autor si no es el mismo usuario
      if (post.authorId !== userId) {
        await prisma.notification.create({
          data: {
            type: 'POST_UPVOTE',
            recipientId: post.authorId,
            actorId: userId,
            postId,
            message: 'Le dio upvote a tu post.',
          },
        })
      }

      return reply.send({ upvoted: true, count: post.upvotesCount })
    }
  })

  // GET /api/posts/:id/comments
  app.get('/:id/comments', async (request, reply) => {
    const { id: postId } = request.params as { id: string }
    const comments = await prisma.comment.findMany({
      where: { postId, parentId: null },
      orderBy: { createdAt: 'asc' },
      select: {
        id: true, content: true, createdAt: true,
        author: { select: { id: true, username: true, displayName: true, avatarUrl: true } },
        replies: {
          select: {
            id: true, content: true, createdAt: true,
            author: { select: { id: true, username: true, displayName: true, avatarUrl: true } },
          },
          orderBy: { createdAt: 'asc' },
        },
      },
    })
    return reply.send({ data: comments })
  })

  // POST /api/posts/:id/comments
  app.post('/:id/comments', { preHandler: authenticate }, async (request, reply) => {
    const { userId } = request.user as { userId: string }
    const { id: postId } = request.params as { id: string }
    const { content, parentId } = request.body as { content: string; parentId?: string }

    if (!content?.trim()) return reply.status(400).send({ message: 'El comentario no puede estar vacío.' })

    const comment = await prisma.comment.create({
      data: { content: content.trim(), authorId: userId, postId, parentId },
      select: {
        id: true, content: true, createdAt: true,
        author: { select: { id: true, username: true, displayName: true, avatarUrl: true } },
      },
    })

    await prisma.post.update({ where: { id: postId }, data: { commentsCount: { increment: 1 } } })

    return reply.status(201).send(comment)
  })

  // DELETE /api/posts/:id
  app.delete('/:id', { preHandler: authenticate }, async (request, reply) => {
    const { userId } = request.user as { userId: string }
    const { id } = request.params as { id: string }

    const post = await prisma.post.findUnique({ where: { id }, select: { authorId: true } })
    if (!post) return reply.status(404).send({ message: 'Post no encontrado.' })
    if (post.authorId !== userId) return reply.status(403).send({ message: 'Sin permisos para eliminar este post.' })

    await prisma.post.delete({ where: { id } })
    return reply.send({ success: true })
  })
}
