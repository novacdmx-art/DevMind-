// apps/api/src/routes/auth.routes.ts
import { FastifyInstance } from 'fastify'
import { z } from 'zod'
import bcrypt from 'bcryptjs'
import { prisma } from '@devmind/db'
import { authenticate } from '../middleware/auth.middleware'

const registerSchema = z.object({
  username: z.string().min(3).max(30).regex(/^[a-zA-Z0-9_]+$/, 'Solo letras, números y guión bajo'),
  email: z.string().email(),
  password: z.string().min(8),
  displayName: z.string().min(2).max(60),
})

const loginSchema = z.object({
  email: z.string().email(),
  password: z.string(),
})

export async function authRoutes(app: FastifyInstance) {
  // POST /api/auth/register
  app.post('/register', {
    config: { rateLimit: { max: 10, timeWindow: '1 minute' } },
  }, async (request, reply) => {
    const body = registerSchema.safeParse(request.body)
    if (!body.success) {
      return reply.status(400).send({ statusCode: 400, message: body.error.errors[0].message })
    }

    const { username, email, password, displayName } = body.data

    const exists = await prisma.user.findFirst({
      where: { OR: [{ email }, { username }] },
    })
    if (exists) {
      const field = exists.email === email ? 'email' : 'username'
      return reply.status(409).send({ statusCode: 409, message: `El ${field} ya está en uso.` })
    }

    const passwordHash = await bcrypt.hash(password, 12)
    const user = await prisma.user.create({
      data: { username, email, passwordHash, displayName },
      select: { id: true, username: true, email: true, displayName: true, avatarUrl: true, devScore: true, plan: true },
    })

    const accessToken = app.jwt.sign({ userId: user.id, username: user.username })
    const refreshToken = app.jwt.sign(
      { userId: user.id, type: 'refresh' },
      { expiresIn: process.env.REFRESH_TOKEN_EXPIRES_IN || '30d' }
    )

    await prisma.refreshToken.create({
      data: {
        token: refreshToken,
        userId: user.id,
        expiresAt: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000),
      },
    })

    return reply.status(201).send({ user, accessToken, refreshToken })
  })

  // POST /api/auth/login
  app.post('/login', {
    config: { rateLimit: { max: 10, timeWindow: '1 minute' } },
  }, async (request, reply) => {
    const body = loginSchema.safeParse(request.body)
    if (!body.success) {
      return reply.status(400).send({ statusCode: 400, message: 'Email o contraseña inválidos.' })
    }

    const { email, password } = body.data
    const user = await prisma.user.findUnique({
      where: { email },
      select: { id: true, username: true, email: true, displayName: true, avatarUrl: true, devScore: true, plan: true, passwordHash: true, isActive: true },
    })

    if (!user || !user.passwordHash || !user.isActive) {
      return reply.status(401).send({ statusCode: 401, message: 'Credenciales incorrectas.' })
    }

    const valid = await bcrypt.compare(password, user.passwordHash)
    if (!valid) {
      return reply.status(401).send({ statusCode: 401, message: 'Credenciales incorrectas.' })
    }

    const accessToken = app.jwt.sign({ userId: user.id, username: user.username })
    const refreshToken = app.jwt.sign(
      { userId: user.id, type: 'refresh' },
      { expiresIn: '30d' }
    )

    await prisma.refreshToken.upsert({
      where: { token: refreshToken },
      create: { token: refreshToken, userId: user.id, expiresAt: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000) },
      update: {},
    })

    const { passwordHash: _, ...userPublic } = user
    return reply.send({ user: userPublic, accessToken, refreshToken })
  })

  // POST /api/auth/refresh
  app.post('/refresh', async (request, reply) => {
    const { refreshToken } = request.body as { refreshToken: string }
    if (!refreshToken) {
      return reply.status(400).send({ statusCode: 400, message: 'refreshToken requerido.' })
    }

    const stored = await prisma.refreshToken.findUnique({
      where: { token: refreshToken },
      include: { user: { select: { id: true, username: true, isActive: true } } },
    })

    if (!stored || stored.expiresAt < new Date() || !stored.user.isActive) {
      return reply.status(401).send({ statusCode: 401, message: 'Refresh token inválido o expirado.' })
    }

    const accessToken = app.jwt.sign({ userId: stored.user.id, username: stored.user.username })
    return reply.send({ accessToken })
  })

  // POST /api/auth/logout
  app.post('/logout', { preHandler: authenticate }, async (request, reply) => {
    const { refreshToken } = request.body as { refreshToken?: string }
    if (refreshToken) {
      await prisma.refreshToken.deleteMany({ where: { token: refreshToken } })
    }
    return reply.send({ success: true })
  })

  // GET /api/auth/me
  app.get('/me', { preHandler: authenticate }, async (request, reply) => {
    const { userId } = request.user as { userId: string }
    const user = await prisma.user.findUnique({
      where: { id: userId },
      select: {
        id: true, username: true, email: true, displayName: true,
        avatarUrl: true, bio: true, devScore: true, plan: true, role: true,
        emailVerified: true, createdAt: true,
        _count: { select: { followers: true, following: true, posts: true } },
      },
    })
    if (!user) return reply.status(404).send({ statusCode: 404, message: 'Usuario no encontrado.' })
    return reply.send({ user })
  })
}
