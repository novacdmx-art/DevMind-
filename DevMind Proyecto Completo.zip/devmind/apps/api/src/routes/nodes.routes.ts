// apps/api/src/routes/nodes.routes.ts
import { FastifyInstance } from 'fastify'
import { z } from 'zod'
import { prisma } from '@devmind/db'
import { authenticate, optionalAuthenticate } from '../middleware/auth.middleware'

const createNodeSchema = z.object({
  name: z.string().min(3).max(60),
  slug: z.string().min(3).max(60).regex(/^[a-z0-9-]+$/),
  description: z.string().min(10).max(500),
  iconUrl: z.string().url().optional(),
  isPrivate: z.boolean().optional(),
  tagIds: z.array(z.string()).optional(),
})

export async function nodesRoutes(app: FastifyInstance) {
  // GET /api/nodes
  app.get('/', async (request, reply) => {
    const { search, limit = 30 } = request.query as any
    const nodes = await prisma.node.findMany({
      where: search ? { OR: [{ name: { contains: search, mode: 'insensitive' } }, { description: { contains: search, mode: 'insensitive' } }] } : undefined,
      take: Number(limit),
      orderBy: { membersCount: 'desc' },
      select: {
        id: true, name: true, slug: true, description: true,
        iconUrl: true, membersCount: true, postsCount: true, isPrivate: true,
        tags: { select: { tag: { select: { id: true, name: true, color: true } } } },
      },
    })
    return reply.send({ data: nodes })
  })

  // GET /api/nodes/:slug
  app.get('/:slug', { preHandler: optionalAuthenticate }, async (request, reply) => {
    const { slug } = request.params as { slug: string }
    const userId = (request.user as any)?.userId

    const node = await prisma.node.findUnique({
      where: { slug },
      select: {
        id: true, name: true, slug: true, description: true, iconUrl: true,
        coverUrl: true, membersCount: true, postsCount: true, isPrivate: true, createdAt: true,
        tags: { select: { tag: { select: { id: true, name: true, color: true } } } },
        members: {
          where: { role: { in: ['FOUNDER', 'MAINTAINER'] } },
          take: 10,
          select: { role: true, user: { select: { id: true, username: true, displayName: true, avatarUrl: true, devScore: true } } },
        },
      },
    })
    if (!node) return reply.status(404).send({ message: 'Nodo no encontrado.' })

    let isMember = false
    let myRole = null
    if (userId) {
      const membership = await prisma.nodeMember.findUnique({ where: { userId_nodeId: { userId, nodeId: node.id } } })
      isMember = !!membership
      myRole = membership?.role || null
    }

    return reply.send({ ...node, isMember, myRole })
  })

  // POST /api/nodes
  app.post('/', { preHandler: authenticate }, async (request, reply) => {
    const { userId } = request.user as { userId: string }
    const body = createNodeSchema.safeParse(request.body)
    if (!body.success) return reply.status(400).send({ message: body.error.errors[0].message })

    const { tagIds, ...nodeData } = body.data
    const node = await prisma.node.create({
      data: {
        ...nodeData,
        membersCount: 1,
        tags: tagIds?.length ? { create: tagIds.map(tagId => ({ tagId })) } : undefined,
        members: { create: { userId, role: 'FOUNDER' } },
      },
    })
    return reply.status(201).send(node)
  })

  // POST /api/nodes/:slug/join
  app.post('/:slug/join', { preHandler: authenticate }, async (request, reply) => {
    const { userId } = request.user as { userId: string }
    const { slug } = request.params as { slug: string }

    const node = await prisma.node.findUnique({ where: { slug } })
    if (!node) return reply.status(404).send({ message: 'Nodo no encontrado.' })

    const existing = await prisma.nodeMember.findUnique({ where: { userId_nodeId: { userId, nodeId: node.id } } })
    if (existing) return reply.status(409).send({ message: 'Ya eres miembro de este nodo.' })

    await prisma.nodeMember.create({ data: { userId, nodeId: node.id } })
    await prisma.node.update({ where: { id: node.id }, data: { membersCount: { increment: 1 } } })

    return reply.send({ success: true, message: `Te uniste a ${node.name}` })
  })

  // DELETE /api/nodes/:slug/leave
  app.delete('/:slug/leave', { preHandler: authenticate }, async (request, reply) => {
    const { userId } = request.user as { userId: string }
    const { slug } = request.params as { slug: string }

    const node = await prisma.node.findUnique({ where: { slug } })
    if (!node) return reply.status(404).send({ message: 'Nodo no encontrado.' })

    await prisma.nodeMember.delete({ where: { userId_nodeId: { userId, nodeId: node.id } } })
    await prisma.node.update({ where: { id: node.id }, data: { membersCount: { decrement: 1 } } })

    return reply.send({ success: true })
  })

  // GET /api/nodes/:slug/posts
  app.get('/:slug/posts', async (request, reply) => {
    const { slug } = request.params as { slug: string }
    const { page = 1, limit = 20 } = request.query as any

    const node = await prisma.node.findUnique({ where: { slug } })
    if (!node) return reply.status(404).send({ message: 'Nodo no encontrado.' })

    const skip = (Number(page) - 1) * Number(limit)
    const posts = await prisma.post.findMany({
      where: { nodeId: node.id, isPublished: true },
      skip, take: Number(limit),
      orderBy: { createdAt: 'desc' },
      select: {
        id: true, type: true, title: true, content: true, codeContent: true, language: true,
        upvotesCount: true, commentsCount: true, createdAt: true,
        author: { select: { id: true, username: true, displayName: true, avatarUrl: true } },
        tags: { select: { tag: { select: { id: true, name: true, color: true } } } },
      },
    })
    return reply.send({ data: posts, page: Number(page), hasMore: posts.length === Number(limit) })
  })
}
