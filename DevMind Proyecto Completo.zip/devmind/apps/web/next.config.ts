// apps/web/next.config.ts
import type { NextConfig } from 'next'

const nextConfig: NextConfig = {
  images: {
    domains: ['avatars.githubusercontent.com', 'lh3.googleusercontent.com'],
    remotePatterns: [{ protocol: 'https', hostname: '**.supabase.co' }],
  },
  env: {
    NEXT_PUBLIC_API_URL: process.env.API_URL || 'http://localhost:4000',
    NEXT_PUBLIC_WS_URL: process.env.API_URL || 'http://localhost:4000',
  },
}

export default nextConfig
