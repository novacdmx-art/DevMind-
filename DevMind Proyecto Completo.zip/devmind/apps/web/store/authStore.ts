'use client'
// apps/web/store/authStore.ts
import { create } from 'zustand'
import { UserPublic } from '@devmind/types'
import api from '../lib/api'

interface AuthState {
  user: UserPublic | null
  isAuthenticated: boolean
  isLoading: boolean

  login: (email: string, password: string) => Promise<void>
  register: (data: { username: string; email: string; password: string; displayName: string }) => Promise<void>
  logout: () => Promise<void>
  fetchMe: () => Promise<void>
  setUser: (user: UserPublic | null) => void
}

export const useAuthStore = create<AuthState>((set, get) => ({
  user: null,
  isAuthenticated: false,
  isLoading: false,

  login: async (email, password) => {
    set({ isLoading: true })
    try {
      const { user, accessToken, refreshToken } = await api.post<any>('/api/auth/login', { email, password }, { skipAuth: true })
      localStorage.setItem('devmind_token', accessToken)
      localStorage.setItem('devmind_refresh', refreshToken)
      set({ user, isAuthenticated: true, isLoading: false })
    } catch (error) {
      set({ isLoading: false })
      throw error
    }
  },

  register: async (data) => {
    set({ isLoading: true })
    try {
      const { user, accessToken, refreshToken } = await api.post<any>('/api/auth/register', data, { skipAuth: true })
      localStorage.setItem('devmind_token', accessToken)
      localStorage.setItem('devmind_refresh', refreshToken)
      set({ user, isAuthenticated: true, isLoading: false })
    } catch (error) {
      set({ isLoading: false })
      throw error
    }
  },

  logout: async () => {
    const refreshToken = localStorage.getItem('devmind_refresh')
    await api.post('/api/auth/logout', { refreshToken }).catch(() => {})
    localStorage.removeItem('devmind_token')
    localStorage.removeItem('devmind_refresh')
    set({ user: null, isAuthenticated: false })
  },

  fetchMe: async () => {
    const token = localStorage.getItem('devmind_token')
    if (!token) return set({ isLoading: false })
    set({ isLoading: true })
    try {
      const { user } = await api.get<any>('/api/auth/me')
      set({ user, isAuthenticated: true, isLoading: false })
    } catch {
      set({ user: null, isAuthenticated: false, isLoading: false })
    }
  },

  setUser: (user) => set({ user, isAuthenticated: !!user }),
}))
