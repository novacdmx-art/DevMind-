// apps/web/tailwind.config.ts
import type { Config } from 'tailwindcss'

const config: Config = {
  darkMode: 'class',
  content: [
    './app/**/*.{js,ts,jsx,tsx,mdx}',
    './components/**/*.{js,ts,jsx,tsx,mdx}',
    './styles/**/*.css',
  ],
  theme: {
    extend: {
      colors: {
        bg:      'var(--bg)',
        surface: {
          DEFAULT: 'var(--surface)',
          2:       'var(--surface-2)',
          3:       'var(--surface-3)',
        },
        purple: {
          DEFAULT: 'var(--purple)',
          light:   'var(--purple-light)',
          dark:    'var(--purple-dark)',
        },
        cyan:    'var(--cyan)',
        green:   'var(--green)',
        yellow:  'var(--yellow)',
        red:     'var(--red)',
        border: {
          DEFAULT: 'var(--border)',
          light:   'var(--border-light)',
        },
        text: {
          DEFAULT: 'var(--text)',
          muted:   'var(--text-muted)',
          faint:   'var(--text-faint)',
        },
      },
      fontFamily: {
        sans: ['Inter', 'system-ui', 'sans-serif'],
        mono: ['JetBrains Mono', 'Fira Code', 'monospace'],
      },
      borderRadius: {
        sm:  'var(--radius-sm)',
        md:  'var(--radius-md)',
        lg:  'var(--radius-lg)',
        xl:  'var(--radius-xl)',
      },
      transitionDuration: {
        DEFAULT: '150ms',
      },
      animation: {
        'fade-in':       'fade-in 0.3s ease-out forwards',
        'pulse-purple':  'pulse-purple 2s ease-in-out infinite',
        'skeleton':      'skeleton-shimmer 1.5s infinite',
      },
      keyframes: {
        'fade-in': {
          from: { opacity: '0', transform: 'translateY(8px)' },
          to:   { opacity: '1', transform: 'translateY(0)' },
        },
        'pulse-purple': {
          '0%, 100%': { boxShadow: '0 0 0 0 rgba(124, 58, 237, 0.35)' },
          '50%':      { boxShadow: '0 0 0 8px transparent' },
        },
        'skeleton-shimmer': {
          '0%':   { backgroundPosition: '-200% 0' },
          '100%': { backgroundPosition: '200% 0' },
        },
      },
      boxShadow: {
        'glow-purple': '0 0 20px rgba(124, 58, 237, 0.35), 0 0 40px rgba(124, 58, 237, 0.1)',
        'glow-cyan':   '0 0 20px rgba(6, 182, 212, 0.3)',
        'card':        '0 4px 24px rgba(0, 0, 0, 0.4)',
      },
    },
  },
  plugins: [],
}

export default config
