'use client'
// apps/web/components/layout/Sidebar.tsx
import Link from 'next/link'
import { usePathname } from 'next/navigation'
import { Home, Compass, Briefcase, ShoppingBag, Settings, TrendingUp, Users } from 'lucide-react'
import { clsx } from 'clsx'

const navItems = [
  { href: '/main/feed',     icon: Home,        label: 'Feed',       badge: null },
  { href: '/main/nodes',    icon: Compass,     label: 'Explorar',   badge: null },
  { href: '/main/jobs',     icon: Briefcase,   label: 'Empleos',    badge: 'Beta' },
  { href: '/main/market',   icon: ShoppingBag, label: 'Marketplace',badge: 'Beta' },
  { href: '/main/settings', icon: Settings,    label: 'Ajustes',    badge: null },
]

export function Sidebar() {
  const pathname = usePathname()

  return (
    <aside className="hidden md:flex flex-col w-56 shrink-0 sticky top-14 h-[calc(100vh-3.5rem)] pt-6 pb-4 pl-2 pr-4 overflow-y-auto">
      <nav className="flex flex-col gap-1">
        {navItems.map(({ href, icon: Icon, label, badge }) => {
          const active = pathname.startsWith(href)
          return (
            <Link
              key={href}
              href={href}
              className={clsx(
                'flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-all duration-150',
                active
                  ? 'bg-purple-ghost text-purple-light'
                  : 'text-text-muted hover:bg-surface-2 hover:text-text'
              )}
            >
              <Icon className={clsx('w-4 h-4 flex-shrink-0', active && 'text-purple-light')} />
              <span>{label}</span>
              {badge && (
                <span className="ml-auto text-[10px] font-bold text-purple-light bg-purple-ghost px-1.5 py-0.5 rounded">
                  {badge}
                </span>
              )}
            </Link>
          )
        })}
      </nav>

      {/* Trending tags */}
      <div className="mt-8 pt-6 border-t border-border">
        <div className="flex items-center gap-2 px-3 mb-3">
          <TrendingUp className="w-3.5 h-3.5 text-text-faint" />
          <span className="text-xs font-semibold text-text-faint uppercase tracking-wider">Trending</span>
        </div>
        {['typescript', 'llm', 'rust', 'nextjs', 'python'].map(tag => (
          <Link
            key={tag}
            href={`/main/feed?tag=${tag}`}
            className="flex items-center gap-2 px-3 py-1.5 rounded text-sm text-text-muted hover:text-cyan transition-colors"
          >
            <span className="text-text-faint">#</span>
            {tag}
          </Link>
        ))}
      </div>
    </aside>
  )
}
