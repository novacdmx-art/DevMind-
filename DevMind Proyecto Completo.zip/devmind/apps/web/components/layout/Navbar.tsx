'use client'
// apps/web/components/layout/Navbar.tsx
import Link from 'next/link'
import { usePathname } from 'next/navigation'
import { Bell, Search, PenSquare, Zap } from 'lucide-react'
import { clsx } from 'clsx'
import { Avatar } from '../ui/Avatar'
import { Button } from '../ui/Button'
import { useAuthStore } from '../../store/authStore'

export function Navbar() {
  const pathname = usePathname()
  const { user, isAuthenticated } = useAuthStore()

  return (
    <header className="fixed top-0 left-0 right-0 z-50 h-14 glass border-b border-border">
      <div className="max-w-screen-xl mx-auto h-full flex items-center justify-between px-4 gap-4">

        {/* Logo */}
        <Link href="/" className="flex items-center gap-2 flex-shrink-0">
          <div className="w-7 h-7 rounded-lg bg-purple flex items-center justify-center shadow-glow-purple">
            <Zap className="w-4 h-4 text-white fill-current" />
          </div>
          <span className="font-bold text-lg gradient-text hidden sm:block">DevMind</span>
        </Link>

        {/* Búsqueda */}
        <div className="flex-1 max-w-md hidden md:block">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-text-faint" />
            <input
              type="text"
              placeholder="Buscar posts, nodos, devs..."
              className="w-full bg-surface-2 border border-border rounded-lg pl-9 pr-4 py-2 text-sm text-text placeholder:text-text-faint focus:outline-none focus:border-purple transition-colors"
            />
          </div>
        </div>

        {/* Acciones */}
        <div className="flex items-center gap-2 flex-shrink-0">
          {isAuthenticated && user ? (
            <>
              {/* Nuevo post */}
              <Button variant="primary" size="sm" leftIcon={<PenSquare className="w-3.5 h-3.5" />}>
                <span className="hidden sm:block">Publicar</span>
              </Button>

              {/* Notificaciones */}
              <button className="relative p-2 rounded-lg text-text-muted hover:text-purple-light hover:bg-purple-ghost transition-all">
                <Bell className="w-5 h-5" />
                <span className="absolute top-1 right-1 w-2 h-2 bg-purple rounded-full" />
              </button>

              {/* Avatar */}
              <Link href={`/profile/${user.username}`}>
                <Avatar src={user.avatarUrl} alt={user.displayName} size="sm" devScore={user.devScore} />
              </Link>
            </>
          ) : (
            <>
              <Link href="/auth/login">
                <Button variant="ghost" size="sm">Entrar</Button>
              </Link>
              <Link href="/auth/register">
                <Button variant="primary" size="sm">Unirse</Button>
              </Link>
            </>
          )}
        </div>
      </div>
    </header>
  )
}
