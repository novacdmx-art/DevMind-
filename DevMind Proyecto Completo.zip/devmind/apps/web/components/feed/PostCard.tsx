'use client'
// apps/web/components/feed/PostCard.tsx
import Link from 'next/link'
import { useState } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { ArrowUp, MessageSquare, Eye, Code2, FileText, HelpCircle, Zap } from 'lucide-react'
import { formatDistanceToNow } from 'date-fns'
import { es } from 'date-fns/locale'
import { PostWithAuthor } from '@devmind/types'
import { Avatar } from '../ui/Avatar'
import { Badge, TechBadge, postTypeVariant } from '../ui/Badge'
import { Card } from '../ui/Card'
import api from '../../lib/api'
import { clsx } from 'clsx'

const postTypeIcons = {
  CODE:    <Code2    className="w-3 h-3" />,
  ARTICLE: <FileText className="w-3 h-3" />,
  QUESTION:<HelpCircle className="w-3 h-3" />,
  DEBATE:  <Zap      className="w-3 h-3" />,
}

const postTypeLabels = {
  CODE: 'Código', ARTICLE: 'Artículo', QUESTION: 'Pregunta', DEBATE: 'Debate'
}

interface PostCardProps {
  post: PostWithAuthor
  currentUserId?: string
}

export function PostCard({ post, currentUserId }: PostCardProps) {
  const [upvotes, setUpvotes] = useState(post.upvotesCount)
  const [hasUpvoted, setHasUpvoted] = useState(post.hasUpvoted || false)
  const [isVoting, setIsVoting] = useState(false)

  const timeAgo = formatDistanceToNow(new Date(post.createdAt), { addSuffix: true, locale: es })

  const handleUpvote = async (e: React.MouseEvent) => {
    e.preventDefault()
    if (!currentUserId || isVoting) return
    setIsVoting(true)

    const wasUpvoted = hasUpvoted
    // Optimistic update
    setHasUpvoted(!wasUpvoted)
    setUpvotes(prev => wasUpvoted ? prev - 1 : prev + 1)

    try {
      await api.post(`/api/posts/${post.id}/upvote`)
    } catch {
      // Revertir si falla
      setHasUpvoted(wasUpvoted)
      setUpvotes(prev => wasUpvoted ? prev + 1 : prev - 1)
    }
    setIsVoting(false)
  }

  return (
    <Card className="group animate-fade-in" padding="none">
      <div className="flex gap-0">
        {/* Columna upvote */}
        <div className="flex flex-col items-center pt-4 px-3 gap-1 min-w-[52px]">
          <motion.button
            onClick={handleUpvote}
            whileTap={{ scale: 0.85 }}
            className={clsx(
              'flex flex-col items-center gap-0.5 p-1.5 rounded-lg transition-all duration-150',
              hasUpvoted
                ? 'text-purple-light bg-purple-ghost'
                : 'text-text-faint hover:text-purple-light hover:bg-purple-ghost',
              !currentUserId && 'cursor-default opacity-50'
            )}
            title={currentUserId ? (hasUpvoted ? 'Quitar upvote' : 'Dar upvote') : 'Inicia sesión para votar'}
          >
            <AnimatePresence mode="wait">
              <motion.div
                key={hasUpvoted ? 'up' : 'down'}
                initial={{ scale: 0.5, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                exit={{ scale: 0.5, opacity: 0 }}
                transition={{ duration: 0.15 }}
              >
                <ArrowUp className={clsx('w-5 h-5', hasUpvoted && 'fill-current')} />
              </motion.div>
            </AnimatePresence>
            <span className="text-xs font-bold tabular-nums">{upvotes}</span>
          </motion.button>
        </div>

        {/* Contenido principal */}
        <div className="flex-1 py-4 pr-4 min-w-0">
          {/* Header */}
          <div className="flex items-start justify-between gap-2 mb-3">
            <div className="flex items-center gap-2 flex-wrap">
              <Link href={`/profile/${post.author.username}`} className="flex items-center gap-2 group/author">
                <Avatar src={post.author.avatarUrl} alt={post.author.displayName} size="sm" devScore={post.author.devScore} />
                <span className="text-sm font-medium text-text-muted group-hover/author:text-purple-light transition-colors">
                  @{post.author.username}
                </span>
              </Link>
              {post.node && (
                <>
                  <span className="text-text-faint text-xs">en</span>
                  <Link href={`/nodes/${post.node.slug}`} className="text-xs font-medium text-cyan hover:text-purple-light transition-colors">
                    {post.node.name}
                  </Link>
                </>
              )}
            </div>
            <div className="flex items-center gap-2 flex-shrink-0">
              <Badge variant={postTypeVariant[post.type] || 'muted'}>
                {postTypeIcons[post.type]}
                {postTypeLabels[post.type]}
              </Badge>
              <span className="text-xs text-text-faint whitespace-nowrap">{timeAgo}</span>
            </div>
          </div>

          {/* Título */}
          {post.title && (
            <Link href={`/posts/${post.id}`}>
              <h3 className="text-base font-semibold text-text hover:text-purple-light transition-colors mb-2 leading-snug">
                {post.title}
              </h3>
            </Link>
          )}

          {/* Contenido */}
          <p className="text-sm text-text-muted line-clamp-2 mb-3 leading-relaxed">
            {post.content}
          </p>

          {/* Preview de código */}
          {post.codeContent && (
            <div className="rounded-md border border-border bg-[#13111C] p-3 mb-3 overflow-x-auto">
              <div className="flex items-center justify-between mb-2">
                <span className="text-xs font-mono text-text-faint">{post.language || 'code'}</span>
                <Code2 className="w-3.5 h-3.5 text-text-faint" />
              </div>
              <pre className="text-xs text-cyan font-mono line-clamp-4 whitespace-pre-wrap break-all">
                {post.codeContent.slice(0, 300)}{post.codeContent.length > 300 ? '...' : ''}
              </pre>
            </div>
          )}

          {/* Footer */}
          <div className="flex items-center justify-between">
            {/* Tags */}
            <div className="flex items-center gap-1.5 flex-wrap">
              {post.tags.slice(0, 4).map(({ tag }) => (
                <TechBadge key={tag.id} name={tag.name} color={tag.color} />
              ))}
            </div>

            {/* Métricas */}
            <div className="flex items-center gap-3 text-text-faint text-xs flex-shrink-0">
              <Link href={`/posts/${post.id}#comments`} className="flex items-center gap-1 hover:text-purple-light transition-colors">
                <MessageSquare className="w-3.5 h-3.5" />
                <span>{post.commentsCount}</span>
              </Link>
              <span className="flex items-center gap-1">
                <Eye className="w-3.5 h-3.5" />
                <span>{post.viewsCount}</span>
              </span>
            </div>
          </div>
        </div>
      </div>
    </Card>
  )
}
