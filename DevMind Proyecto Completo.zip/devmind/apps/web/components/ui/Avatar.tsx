'use client'
// apps/web/components/ui/Avatar.tsx
import Image from 'next/image'
import { clsx } from 'clsx'

interface AvatarProps {
  src?: string | null
  alt: string
  username?: string
  size?: 'xs' | 'sm' | 'md' | 'lg' | 'xl'
  devScore?: number
  className?: string
}

const sizes = {
  xs:  { wrapper: 'w-6  h-6',  text: 'text-[10px]' },
  sm:  { wrapper: 'w-8  h-8',  text: 'text-xs' },
  md:  { wrapper: 'w-10 h-10', text: 'text-sm' },
  lg:  { wrapper: 'w-14 h-14', text: 'text-lg' },
  xl:  { wrapper: 'w-20 h-20', text: 'text-2xl' },
}

// Color del ring según DevScore
function getScoreRing(score?: number): string {
  if (!score) return 'ring-border'
  if (score >= 2000) return 'ring-yellow'    // Gold
  if (score >= 1000) return 'ring-purple-light' // Purple
  if (score >= 500)  return 'ring-cyan'      // Cyan
  return 'ring-border'
}

export function Avatar({ src, alt, username, size = 'md', devScore, className }: AvatarProps) {
  const { wrapper, text } = sizes[size]
  const initials = (username || alt).slice(0, 2).toUpperCase()
  const ringColor = getScoreRing(devScore)

  return (
    <div
      className={clsx(
        'relative rounded-full overflow-hidden flex-shrink-0',
        'ring-2 ring-offset-1 ring-offset-surface',
        ringColor,
        wrapper,
        className
      )}
    >
      {src ? (
        <Image src={src} alt={alt} fill className="object-cover" />
      ) : (
        <div className={clsx('w-full h-full flex items-center justify-center bg-purple-ghost font-bold', text, 'text-purple-light')}>
          {initials}
        </div>
      )}
    </div>
  )
}
