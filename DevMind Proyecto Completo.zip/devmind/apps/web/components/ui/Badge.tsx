'use client'
// apps/web/components/ui/Badge.tsx
import { HTMLAttributes } from 'react'
import { clsx } from 'clsx'

type BadgeVariant = 'purple' | 'cyan' | 'green' | 'yellow' | 'red' | 'muted'

const variantClasses: Record<BadgeVariant, string> = {
  purple: 'bg-purple-ghost text-purple-light border border-purple/30',
  cyan:   'bg-cyan-ghost   text-cyan         border border-cyan/30',
  green:  'bg-green-ghost  text-green        border border-green/30',
  yellow: 'bg-yellow-ghost text-yellow       border border-yellow/30',
  red:    'bg-red-ghost    text-red          border border-red/30',
  muted:  'bg-surface-2    text-text-muted   border border-border',
}

// Mappear tipo de post a variante
export const postTypeVariant: Record<string, BadgeVariant> = {
  CODE:    'cyan',
  ARTICLE: 'purple',
  QUESTION:'yellow',
  DEBATE:  'red',
}

interface BadgeProps extends HTMLAttributes<HTMLSpanElement> {
  variant?: BadgeVariant
}

export function Badge({ variant = 'muted', className, children, ...props }: BadgeProps) {
  return (
    <span
      className={clsx(
        'inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-semibold whitespace-nowrap',
        variantClasses[variant],
        className
      )}
      {...props}
    >
      {children}
    </span>
  )
}

// Badge de tecnología con color personalizado
interface TechBadgeProps {
  name: string
  color?: string
}

export function TechBadge({ name, color = '#06B6D4' }: TechBadgeProps) {
  return (
    <span
      className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-semibold border whitespace-nowrap"
      style={{
        backgroundColor: `${color}1A`,
        color: color,
        borderColor: `${color}4D`,
      }}
    >
      {name}
    </span>
  )
}
