// apps/web/app/layout.tsx
import type { Metadata } from 'next'
import '../styles/globals.css'
import { Providers } from './providers'

export const metadata: Metadata = {
  title: { default: 'DevMind', template: '%s | DevMind' },
  description: 'La red social-productiva para desarrolladores e investigadores de IA.',
  keywords: ['programación', 'desarrolladores', 'IA', 'comunidad', 'código'],
  themeColor: '#7C3AED',
  openGraph: {
    siteName: 'DevMind',
    type: 'website',
  },
}

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="es" className="dark">
      <body className="bg-bg text-text font-sans antialiased">
        <Providers>{children}</Providers>
      </body>
    </html>
  )
}
