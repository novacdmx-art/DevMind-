// apps/web/app/main/layout.tsx
import { Navbar } from '../../components/layout/Navbar'
import { Sidebar } from '../../components/layout/Sidebar'

export default function MainLayout({ children }: { children: React.ReactNode }) {
  return (
    <div className="min-h-screen bg-bg">
      <Navbar />
      <div className="flex pt-14 max-w-screen-xl mx-auto">
        <Sidebar />
        <main className="flex-1 min-w-0 px-4 py-6 md:px-6">
          {children}
        </main>
      </div>
    </div>
  )
}
