'use client'
// apps/web/app/main/feed/FeedClient.tsx
import { useState } from 'react'
import { useQuery } from '@tanstack/react-query'
import { Flame, Clock, Sparkles } from 'lucide-react'
import { PostCard } from '../../../components/feed/PostCard'
import { useAuthStore } from '../../../store/authStore'
import api from '../../../lib/api'
import { clsx } from 'clsx'

type FeedTab = 'trending' | 'latest' | 'following'

const tabs = [
  { id: 'trending' as FeedTab,  label: 'Trending',  icon: Flame },
  { id: 'latest' as FeedTab,    label: 'Recientes', icon: Clock },
  { id: 'following' as FeedTab, label: 'Siguiendo', icon: Sparkles },
]

export function FeedClient() {
  const [activeTab, setActiveTab] = useState<FeedTab>('trending')
  const { user, isAuthenticated } = useAuthStore()

  const { data, isLoading } = useQuery({
    queryKey: ['feed', activeTab],
    queryFn: async () => {
      if (activeTab === 'trending') return api.get<any>('/api/feed/trending')
      if (activeTab === 'following' && isAuthenticated) return api.get<any>('/api/feed')
      return api.get<any>('/api/posts')
    },
  })

  const posts = data?.data || []

  return (
    <div className="max-w-2xl mx-auto">
      {/* Tabs */}
      <div className="flex items-center gap-1 mb-6 bg-surface rounded-xl p-1 border border-border">
        {tabs.map(({ id, label, icon: Icon }) => {
          const active = activeTab === id
          const locked = id === 'following' && !isAuthenticated
          return (
            <button
              key={id}
              onClick={() => !locked && setActiveTab(id)}
              disabled={locked}
              className={clsx(
                'flex-1 flex items-center justify-center gap-2 px-4 py-2 rounded-lg text-sm font-medium transition-all duration-150',
                active ? 'bg-purple text-white shadow-glow-purple' : 'text-text-muted hover:text-text',
                locked && 'opacity-40 cursor-not-allowed'
              )}
            >
              <Icon className="w-4 h-4" />
              <span className="hidden sm:block">{label}</span>
            </button>
          )
        })}
      </div>

      {/* Posts */}
      <div className="flex flex-col gap-3">
        {isLoading ? (
          // Skeleton
          Array.from({ length: 5 }).map((_, i) => (
            <div key={i} className="bg-surface border border-border rounded-lg p-4 animate-fade-in">
              <div className="flex gap-3">
                <div className="skeleton w-8 h-8 rounded-full" />
                <div className="flex-1 space-y-2">
                  <div className="skeleton h-4 w-1/3 rounded" />
                  <div className="skeleton h-3 w-full rounded" />
                  <div className="skeleton h-3 w-2/3 rounded" />
                </div>
              </div>
            </div>
          ))
        ) : posts.length === 0 ? (
          <div className="text-center py-16">
            <p className="text-text-muted text-sm">No hay posts aquí todavía.</p>
            {activeTab === 'following' && (
              <p className="text-text-faint text-xs mt-1">Sigue a otros devs para ver su contenido aquí.</p>
            )}
          </div>
        ) : (
          posts.map((post: any) => (
            <PostCard key={post.id} post={post} currentUserId={user?.id} />
          ))
        )}
      </div>
    </div>
  )
}
