// apps/web/app/main/feed/page.tsx
import type { Metadata } from 'next'
import { FeedClient } from './FeedClient'

export const metadata: Metadata = { title: 'Feed' }

export default function FeedPage() {
  return <FeedClient />
}
