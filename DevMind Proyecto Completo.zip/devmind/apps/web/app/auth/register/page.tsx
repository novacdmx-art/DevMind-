'use client'
// apps/web/app/auth/register/page.tsx
import { useState } from 'react'
import Link from 'next/link'
import { useRouter } from 'next/navigation'
import { motion } from 'framer-motion'
import { Zap, Mail, Lock, User, AtSign, AlertCircle } from 'lucide-react'
import { Button } from '../../../components/ui/Button'
import { useAuthStore } from '../../../store/authStore'

export default function RegisterPage() {
  const router = useRouter()
  const { register, isLoading } = useAuthStore()
  const [form, setForm] = useState({ username: '', email: '', password: '', displayName: '' })
  const [error, setError] = useState('')

  const update = (field: string) => (e: React.ChangeEvent<HTMLInputElement>) =>
    setForm(prev => ({ ...prev, [field]: e.target.value }))

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setError('')
    try {
      await register(form)
      router.push('/main/feed')
    } catch (err: any) {
      setError(err?.message || 'Error al registrarse. Intenta de nuevo.')
    }
  }

  return (
    <div className="min-h-screen bg-bg flex items-center justify-center p-4">
      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="w-full max-w-sm">
        <div className="flex flex-col items-center mb-8">
          <div className="w-12 h-12 rounded-2xl bg-purple flex items-center justify-center shadow-glow-purple mb-4">
            <Zap className="w-6 h-6 text-white fill-current" />
          </div>
          <h1 className="text-2xl font-bold gradient-text">Únete a DevMind</h1>
          <p className="text-text-muted text-sm mt-1">La comunidad de devs que construye en serio</p>
        </div>

        <div className="bg-surface border border-border rounded-xl p-6">
          <form onSubmit={handleSubmit} className="space-y-4">
            {error && (
              <motion.div initial={{ opacity: 0, x: -8 }} animate={{ opacity: 1, x: 0 }}
                className="flex items-center gap-2 bg-red-ghost border border-red/30 text-red rounded-lg px-3 py-2.5 text-sm">
                <AlertCircle className="w-4 h-4 flex-shrink-0" />{error}
              </motion.div>
            )}

            {[
              { field: 'displayName', label: 'Nombre', icon: User, placeholder: 'Tu nombre', type: 'text' },
              { field: 'username', label: 'Username', icon: AtSign, placeholder: 'tu_username', type: 'text' },
              { field: 'email', label: 'Email', icon: Mail, placeholder: 'tu@email.com', type: 'email' },
              { field: 'password', label: 'Contraseña', icon: Lock, placeholder: '8+ caracteres', type: 'password' },
            ].map(({ field, label, icon: Icon, placeholder, type }) => (
              <div key={field} className="space-y-1">
                <label className="text-xs font-medium text-text-muted">{label}</label>
                <div className="relative">
                  <Icon className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-text-faint" />
                  <input
                    type={type}
                    value={form[field as keyof typeof form]}
                    onChange={update(field)}
                    placeholder={placeholder}
                    required
                    className="w-full bg-surface-2 border border-border rounded-lg pl-9 pr-4 py-2.5 text-sm text-text placeholder:text-text-faint focus:outline-none focus:border-purple transition-colors"
                  />
                </div>
              </div>
            ))}

            <Button type="submit" variant="primary" size="lg" isLoading={isLoading} className="w-full mt-2">
              Crear cuenta gratis
            </Button>
          </form>

          <p className="text-center text-sm text-text-muted mt-4">
            ¿Ya tienes cuenta?{' '}
            <Link href="/auth/login" className="text-purple-light hover:text-cyan transition-colors font-medium">
              Iniciar sesión
            </Link>
          </p>
        </div>
      </motion.div>
    </div>
  )
}
