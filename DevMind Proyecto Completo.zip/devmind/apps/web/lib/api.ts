// apps/web/lib/api.ts
// Cliente HTTP centralizado para el backend de DevMind

const API_URL = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:4000'

function getToken(): string | null {
  if (typeof window === 'undefined') return null
  return localStorage.getItem('devmind_token')
}

interface FetchOptions extends RequestInit {
  skipAuth?: boolean
}

async function fetchApi<T>(endpoint: string, options: FetchOptions = {}): Promise<T> {
  const { skipAuth, ...fetchOptions } = options
  const token = getToken()

  const headers: Record<string, string> = {
    'Content-Type': 'application/json',
    ...(fetchOptions.headers as Record<string, string> || {}),
  }

  if (token && !skipAuth) {
    headers['Authorization'] = `Bearer ${token}`
  }

  const response = await fetch(`${API_URL}${endpoint}`, {
    ...fetchOptions,
    headers,
  })

  // Token expirado — intentar refresh automático
  if (response.status === 401 && !skipAuth) {
    const refreshed = await tryRefreshToken()
    if (refreshed) {
      headers['Authorization'] = `Bearer ${getToken()}`
      const retryResponse = await fetch(`${API_URL}${endpoint}`, { ...fetchOptions, headers })
      if (!retryResponse.ok) throw await retryResponse.json()
      return retryResponse.json()
    }
    // Refresh falló — limpiar sesión
    localStorage.removeItem('devmind_token')
    localStorage.removeItem('devmind_refresh')
    window.location.href = '/auth/login'
  }

  if (!response.ok) {
    const error = await response.json()
    throw error
  }

  // 204 No Content
  if (response.status === 204) return null as T

  return response.json()
}

async function tryRefreshToken(): Promise<boolean> {
  const refreshToken = localStorage.getItem('devmind_refresh')
  if (!refreshToken) return false

  try {
    const res = await fetch(`${API_URL}/api/auth/refresh`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ refreshToken }),
    })
    if (!res.ok) return false
    const { accessToken } = await res.json()
    localStorage.setItem('devmind_token', accessToken)
    return true
  } catch {
    return false
  }
}

// ── Métodos helper ────────────────────────────────────────────────────────────
export const api = {
  get: <T>(url: string, options?: FetchOptions) =>
    fetchApi<T>(url, { method: 'GET', ...options }),

  post: <T>(url: string, body?: unknown, options?: FetchOptions) =>
    fetchApi<T>(url, { method: 'POST', body: JSON.stringify(body), ...options }),

  patch: <T>(url: string, body?: unknown, options?: FetchOptions) =>
    fetchApi<T>(url, { method: 'PATCH', body: JSON.stringify(body), ...options }),

  delete: <T>(url: string, options?: FetchOptions) =>
    fetchApi<T>(url, { method: 'DELETE', ...options }),
}

export default api
